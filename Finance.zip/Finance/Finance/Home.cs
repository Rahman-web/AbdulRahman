﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Finance
{
    public partial class Home : Form
    {
        public Home()
        {
            InitializeComponent();
            tm_Time.Start();
            pnl_entry.Hide();
            pnl_administrator.Hide();
            pnl_file.Hide();
            pnl_report.Hide();
            pnl_master.Hide();
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\ashfa\OneDrive\Documents\Finance.mdf;Integrated Security=True;Connect Timeout=30");
            con.Open();
        }
        
        private void btn_exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btn_file_Click(object sender, EventArgs e)
        {
            pnl_slide.Height = btn_file.Height;
            pnl_slide.Top = btn_file.Top;
            pnl_file.Location = new Point(1,169);
            pnl_entry.Hide();
            pnl_administrator.Hide();
            pnl_file.Hide();
            pnl_report.Hide();
            pnl_master.Hide();
            pnl_file.Show();
        }

        private void btn_entry_Click(object sender, EventArgs e)
        {
            pnl_slide.Height = btn_entry.Height;
            pnl_slide.Top = btn_entry.Top;
            pnl_entry.Location = new Point(1, 228);
            pnl_entry.Show();
            pnl_administrator.Hide();
            pnl_file.Hide();
            pnl_report.Hide();
            pnl_master.Hide();

        }

        private void btn_master_Click(object sender, EventArgs e)
        {
            pnl_slide.Height = btn_master.Height;
            pnl_slide.Top = btn_master.Top;
            pnl_master.Show();
            pnl_entry.Hide();
            pnl_administrator.Hide();
            pnl_file.Hide();
            pnl_report.Hide();
            pnl_master.Location = new Point(1, 346);
        }

        
        private void btn_admin_Click(object sender, EventArgs e)
        {
            pnl_slide.Height = btn_admin.Height;
            pnl_slide.Top = btn_admin.Top;
            pnl_master.Hide();
            pnl_file.Hide();
            pnl_entry.Hide();
            pnl_report.Hide();
            pnl_administrator.Show();
            pnl_administrator.Location = new Point(1,405);
        }

        private void btn_mail_Click(object sender, EventArgs e)
        {
            pnl_slide.Height = btn_mail.Height;
            pnl_slide.Top = btn_mail.Top;
            pnl_entry.Hide();
            pnl_administrator.Hide();
            pnl_file.Hide();
            pnl_report.Hide();
            pnl_master.Hide();
        }

        private void btn_about_Click(object sender, EventArgs e)
        {
            pnl_slide.Height = btn_about.Height;
            pnl_slide.Top = btn_about.Top;
            pnl_entry.Hide();
            pnl_administrator.Hide();
            pnl_file.Hide();
            pnl_report.Hide();
            pnl_master.Hide();
        }
        private void btn_report_Click(object sender, EventArgs e)
        {
            pnl_slide.Height = btn_report.Height;
            pnl_slide.Top = btn_report.Top;
            pnl_report.Location = new Point(1, 287);
            pnl_report.Show();
            pnl_administrator.Hide();
            pnl_file.Hide();
            pnl_entry.Hide();
            pnl_master.Hide();
        }

        private void tm_Time_Tick(object sender, EventArgs e)
        {
            lbl_time.Text = System.DateTime.Now.ToString("hh:mm:ss tt");
            lbl_day.Text = System.DateTime.Now.ToString("dddd  dd/MMM/yyyy ");
        }

        private void btn_min_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void btn_slide_Click(object sender, EventArgs e)
        {
            if (pnl_Left.Width == 64)
            {
                pnl_Left.Visible = false;
                pnl_Left.Width = 282;
                Bunifu_Slide.ShowSync(pnl_Left);
                Bunifu_Logo.ShowSync(pb_logo);
                Bunifu_Sname.ShowSync(lbl_soft);
                bunifu_Ash.ShowSync(lbl_ash);
            }
            else
            {
                Bunifu_Sname.Hide(lbl_soft);
                bunifu_Ash.Hide(lbl_ash);
                Bunifu_Sname.Hide(lbl_soft);
                Bunifu_Logo.Hide(pb_logo);
                pnl_Left.Visible = false;
                pnl_Left.Width = 64;
                Bunifu_Slide.ShowSync(pnl_Left);

            }
        }
    }
}
