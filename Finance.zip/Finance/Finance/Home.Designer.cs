﻿namespace Finance
{
    partial class Home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            BunifuAnimatorNS.Animation animation6 = new BunifuAnimatorNS.Animation();
            BunifuAnimatorNS.Animation animation7 = new BunifuAnimatorNS.Animation();
            BunifuAnimatorNS.Animation animation8 = new BunifuAnimatorNS.Animation();
            BunifuAnimatorNS.Animation animation5 = new BunifuAnimatorNS.Animation();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Home));
            this.pnl_all = new System.Windows.Forms.Panel();
            this.pnl_administrator = new System.Windows.Forms.Panel();
            this.button29 = new System.Windows.Forms.Button();
            this.button28 = new System.Windows.Forms.Button();
            this.button24 = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.button38 = new System.Windows.Forms.Button();
            this.button39 = new System.Windows.Forms.Button();
            this.button41 = new System.Windows.Forms.Button();
            this.button42 = new System.Windows.Forms.Button();
            this.button44 = new System.Windows.Forms.Button();
            this.button45 = new System.Windows.Forms.Button();
            this.pnl_report = new System.Windows.Forms.Panel();
            this.button27 = new System.Windows.Forms.Button();
            this.button26 = new System.Windows.Forms.Button();
            this.button25 = new System.Windows.Forms.Button();
            this.pnl_gap4 = new System.Windows.Forms.Panel();
            this.btn_passbookChecking = new System.Windows.Forms.Button();
            this.pnl_gap3 = new System.Windows.Forms.Panel();
            this.button23 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.pnl_gap2 = new System.Windows.Forms.Panel();
            this.button20 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.pnl_gap1 = new System.Windows.Forms.Panel();
            this.button11 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.pnl_file = new System.Windows.Forms.Panel();
            this.button8 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.pnl_master = new System.Windows.Forms.Panel();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.pnl_entry = new System.Windows.Forms.Panel();
            this.btn_collection = new System.Windows.Forms.Button();
            this.btn_loan = new System.Windows.Forms.Button();
            this.pnl_main = new System.Windows.Forms.Panel();
            this.tm_Time = new System.Windows.Forms.Timer(this.components);
            this.pnl_title = new System.Windows.Forms.Panel();
            this.btn_min = new System.Windows.Forms.Button();
            this.lbl_headAsh = new System.Windows.Forms.Label();
            this.btn_exit = new System.Windows.Forms.Button();
            this.pnl_admin = new System.Windows.Forms.Panel();
            this.pnl_outTime = new System.Windows.Forms.Panel();
            this.pnl_inTime = new System.Windows.Forms.Panel();
            this.lbl_day = new System.Windows.Forms.Label();
            this.lbl_time = new System.Windows.Forms.Label();
            this.lbl_usertype = new System.Windows.Forms.Label();
            this.lbl_role = new System.Windows.Forms.Label();
            this.lbl_user = new System.Windows.Forms.Label();
            this.lbl_welcome = new System.Windows.Forms.Label();
            this.pnl_Lefttop = new System.Windows.Forms.Panel();
            this.lbl_ash = new System.Windows.Forms.Label();
            this.btn_slide = new System.Windows.Forms.Button();
            this.lbl_soft = new System.Windows.Forms.Label();
            this.pb_logo = new System.Windows.Forms.PictureBox();
            this.pnl_slide = new System.Windows.Forms.Panel();
            this.pnl_Left = new System.Windows.Forms.Panel();
            this.btn_report = new System.Windows.Forms.Button();
            this.btn_mail = new System.Windows.Forms.Button();
            this.btn_about = new System.Windows.Forms.Button();
            this.btn_file = new System.Windows.Forms.Button();
            this.btn_entry = new System.Windows.Forms.Button();
            this.btn_admin = new System.Windows.Forms.Button();
            this.btn_master = new System.Windows.Forms.Button();
            this.doubleBitmapControl1 = new BunifuAnimatorNS.DoubleBitmapControl();
            this.Bunifu_Logo = new BunifuAnimatorNS.BunifuTransition(this.components);
            this.Bunifu_Slide = new BunifuAnimatorNS.BunifuTransition(this.components);
            this.Bunifu_Sname = new BunifuAnimatorNS.BunifuTransition(this.components);
            this.bunifu_Ash = new BunifuAnimatorNS.BunifuTransition(this.components);
            this.pnl_all.SuspendLayout();
            this.pnl_administrator.SuspendLayout();
            this.pnl_report.SuspendLayout();
            this.pnl_file.SuspendLayout();
            this.pnl_master.SuspendLayout();
            this.pnl_entry.SuspendLayout();
            this.pnl_title.SuspendLayout();
            this.pnl_admin.SuspendLayout();
            this.pnl_outTime.SuspendLayout();
            this.pnl_inTime.SuspendLayout();
            this.pnl_Lefttop.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_logo)).BeginInit();
            this.pnl_Left.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnl_all
            // 
            this.pnl_all.Controls.Add(this.pnl_administrator);
            this.pnl_all.Controls.Add(this.pnl_report);
            this.pnl_all.Controls.Add(this.pnl_file);
            this.pnl_all.Controls.Add(this.pnl_master);
            this.pnl_all.Controls.Add(this.pnl_entry);
            this.pnl_all.Controls.Add(this.pnl_main);
            this.bunifu_Ash.SetDecoration(this.pnl_all, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.pnl_all, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.pnl_all, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Sname.SetDecoration(this.pnl_all, BunifuAnimatorNS.DecorationType.None);
            this.pnl_all.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnl_all.Location = new System.Drawing.Point(235, 0);
            this.pnl_all.Margin = new System.Windows.Forms.Padding(2);
            this.pnl_all.Name = "pnl_all";
            this.pnl_all.Size = new System.Drawing.Size(1151, 787);
            this.pnl_all.TabIndex = 10;
            // 
            // pnl_administrator
            // 
            this.pnl_administrator.BackColor = System.Drawing.Color.White;
            this.pnl_administrator.Controls.Add(this.button29);
            this.pnl_administrator.Controls.Add(this.button28);
            this.pnl_administrator.Controls.Add(this.button24);
            this.pnl_administrator.Controls.Add(this.panel2);
            this.pnl_administrator.Controls.Add(this.button38);
            this.pnl_administrator.Controls.Add(this.button39);
            this.pnl_administrator.Controls.Add(this.button41);
            this.pnl_administrator.Controls.Add(this.button42);
            this.pnl_administrator.Controls.Add(this.button44);
            this.pnl_administrator.Controls.Add(this.button45);
            this.bunifu_Ash.SetDecoration(this.pnl_administrator, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.pnl_administrator, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.pnl_administrator, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Sname.SetDecoration(this.pnl_administrator, BunifuAnimatorNS.DecorationType.None);
            this.pnl_administrator.Location = new System.Drawing.Point(634, 228);
            this.pnl_administrator.Name = "pnl_administrator";
            this.pnl_administrator.Size = new System.Drawing.Size(223, 274);
            this.pnl_administrator.TabIndex = 4;
            // 
            // button29
            // 
            this.button29.BackColor = System.Drawing.Color.White;
            this.Bunifu_Sname.SetDecoration(this.button29, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.button29, BunifuAnimatorNS.DecorationType.None);
            this.bunifu_Ash.SetDecoration(this.button29, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.button29, BunifuAnimatorNS.DecorationType.None);
            this.button29.Dock = System.Windows.Forms.DockStyle.Top;
            this.button29.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.button29.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkGray;
            this.button29.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button29.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button29.ForeColor = System.Drawing.Color.Black;
            this.button29.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button29.Location = new System.Drawing.Point(0, 184);
            this.button29.Margin = new System.Windows.Forms.Padding(2);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(223, 30);
            this.button29.TabIndex = 17;
            this.button29.Text = "More";
            this.button29.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button29.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button29.UseVisualStyleBackColor = false;
            // 
            // button28
            // 
            this.button28.BackColor = System.Drawing.Color.White;
            this.Bunifu_Sname.SetDecoration(this.button28, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.button28, BunifuAnimatorNS.DecorationType.None);
            this.bunifu_Ash.SetDecoration(this.button28, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.button28, BunifuAnimatorNS.DecorationType.None);
            this.button28.Dock = System.Windows.Forms.DockStyle.Top;
            this.button28.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.button28.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkGray;
            this.button28.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button28.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button28.ForeColor = System.Drawing.Color.Black;
            this.button28.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button28.Location = new System.Drawing.Point(0, 154);
            this.button28.Margin = new System.Windows.Forms.Padding(2);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(223, 30);
            this.button28.TabIndex = 16;
            this.button28.Text = "Member Auto no";
            this.button28.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button28.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button28.UseVisualStyleBackColor = false;
            // 
            // button24
            // 
            this.button24.BackColor = System.Drawing.Color.White;
            this.Bunifu_Sname.SetDecoration(this.button24, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.button24, BunifuAnimatorNS.DecorationType.None);
            this.bunifu_Ash.SetDecoration(this.button24, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.button24, BunifuAnimatorNS.DecorationType.None);
            this.button24.Dock = System.Windows.Forms.DockStyle.Top;
            this.button24.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.button24.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkGray;
            this.button24.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button24.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button24.ForeColor = System.Drawing.Color.Black;
            this.button24.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button24.Location = new System.Drawing.Point(0, 124);
            this.button24.Margin = new System.Windows.Forms.Padding(2);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(223, 30);
            this.button24.TabIndex = 15;
            this.button24.Text = "Configuration";
            this.button24.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button24.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button24.UseVisualStyleBackColor = false;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Gray;
            this.bunifu_Ash.SetDecoration(this.panel2, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.panel2, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.panel2, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Sname.SetDecoration(this.panel2, BunifuAnimatorNS.DecorationType.None);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 120);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(223, 4);
            this.panel2.TabIndex = 14;
            // 
            // button38
            // 
            this.button38.BackColor = System.Drawing.Color.White;
            this.Bunifu_Sname.SetDecoration(this.button38, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.button38, BunifuAnimatorNS.DecorationType.None);
            this.bunifu_Ash.SetDecoration(this.button38, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.button38, BunifuAnimatorNS.DecorationType.None);
            this.button38.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.button38.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.button38.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkGray;
            this.button38.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button38.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button38.ForeColor = System.Drawing.Color.Black;
            this.button38.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button38.Location = new System.Drawing.Point(0, 214);
            this.button38.Margin = new System.Windows.Forms.Padding(2);
            this.button38.Name = "button38";
            this.button38.Size = new System.Drawing.Size(223, 30);
            this.button38.TabIndex = 13;
            this.button38.Text = "Delete Collection";
            this.button38.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button38.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button38.UseVisualStyleBackColor = false;
            // 
            // button39
            // 
            this.button39.BackColor = System.Drawing.Color.White;
            this.Bunifu_Sname.SetDecoration(this.button39, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.button39, BunifuAnimatorNS.DecorationType.None);
            this.bunifu_Ash.SetDecoration(this.button39, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.button39, BunifuAnimatorNS.DecorationType.None);
            this.button39.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.button39.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.button39.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkGray;
            this.button39.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button39.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button39.ForeColor = System.Drawing.Color.Black;
            this.button39.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button39.Location = new System.Drawing.Point(0, 244);
            this.button39.Margin = new System.Windows.Forms.Padding(2);
            this.button39.Name = "button39";
            this.button39.Size = new System.Drawing.Size(223, 30);
            this.button39.TabIndex = 12;
            this.button39.Text = "Change Dt Collection";
            this.button39.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button39.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button39.UseVisualStyleBackColor = false;
            // 
            // button41
            // 
            this.button41.BackColor = System.Drawing.Color.White;
            this.Bunifu_Sname.SetDecoration(this.button41, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.button41, BunifuAnimatorNS.DecorationType.None);
            this.bunifu_Ash.SetDecoration(this.button41, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.button41, BunifuAnimatorNS.DecorationType.None);
            this.button41.Dock = System.Windows.Forms.DockStyle.Top;
            this.button41.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.button41.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkGray;
            this.button41.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button41.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button41.ForeColor = System.Drawing.Color.Black;
            this.button41.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button41.Location = new System.Drawing.Point(0, 90);
            this.button41.Margin = new System.Windows.Forms.Padding(2);
            this.button41.Name = "button41";
            this.button41.Size = new System.Drawing.Size(223, 30);
            this.button41.TabIndex = 10;
            this.button41.Text = "Change Date";
            this.button41.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button41.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button41.UseVisualStyleBackColor = false;
            // 
            // button42
            // 
            this.button42.BackColor = System.Drawing.Color.White;
            this.Bunifu_Sname.SetDecoration(this.button42, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.button42, BunifuAnimatorNS.DecorationType.None);
            this.bunifu_Ash.SetDecoration(this.button42, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.button42, BunifuAnimatorNS.DecorationType.None);
            this.button42.Dock = System.Windows.Forms.DockStyle.Top;
            this.button42.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.button42.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkGray;
            this.button42.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button42.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button42.ForeColor = System.Drawing.Color.Black;
            this.button42.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button42.Location = new System.Drawing.Point(0, 60);
            this.button42.Margin = new System.Windows.Forms.Padding(2);
            this.button42.Name = "button42";
            this.button42.Size = new System.Drawing.Size(223, 30);
            this.button42.TabIndex = 9;
            this.button42.Text = "Export to Daybook";
            this.button42.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button42.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button42.UseVisualStyleBackColor = false;
            // 
            // button44
            // 
            this.button44.BackColor = System.Drawing.Color.White;
            this.Bunifu_Sname.SetDecoration(this.button44, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.button44, BunifuAnimatorNS.DecorationType.None);
            this.bunifu_Ash.SetDecoration(this.button44, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.button44, BunifuAnimatorNS.DecorationType.None);
            this.button44.Dock = System.Windows.Forms.DockStyle.Top;
            this.button44.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.button44.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkGray;
            this.button44.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button44.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button44.ForeColor = System.Drawing.Color.Black;
            this.button44.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button44.Location = new System.Drawing.Point(0, 30);
            this.button44.Margin = new System.Windows.Forms.Padding(2);
            this.button44.Name = "button44";
            this.button44.Size = new System.Drawing.Size(223, 30);
            this.button44.TabIndex = 6;
            this.button44.Text = "Compact and Repair";
            this.button44.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button44.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button44.UseVisualStyleBackColor = false;
            // 
            // button45
            // 
            this.button45.BackColor = System.Drawing.Color.White;
            this.Bunifu_Sname.SetDecoration(this.button45, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.button45, BunifuAnimatorNS.DecorationType.None);
            this.bunifu_Ash.SetDecoration(this.button45, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.button45, BunifuAnimatorNS.DecorationType.None);
            this.button45.Dock = System.Windows.Forms.DockStyle.Top;
            this.button45.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.button45.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkGray;
            this.button45.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button45.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button45.ForeColor = System.Drawing.Color.Black;
            this.button45.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button45.Location = new System.Drawing.Point(0, 0);
            this.button45.Margin = new System.Windows.Forms.Padding(2);
            this.button45.Name = "button45";
            this.button45.Size = new System.Drawing.Size(223, 30);
            this.button45.TabIndex = 5;
            this.button45.Text = "Backup";
            this.button45.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button45.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button45.UseVisualStyleBackColor = false;
            // 
            // pnl_report
            // 
            this.pnl_report.BackColor = System.Drawing.Color.White;
            this.pnl_report.Controls.Add(this.button27);
            this.pnl_report.Controls.Add(this.button26);
            this.pnl_report.Controls.Add(this.button25);
            this.pnl_report.Controls.Add(this.pnl_gap4);
            this.pnl_report.Controls.Add(this.btn_passbookChecking);
            this.pnl_report.Controls.Add(this.pnl_gap3);
            this.pnl_report.Controls.Add(this.button23);
            this.pnl_report.Controls.Add(this.button22);
            this.pnl_report.Controls.Add(this.button21);
            this.pnl_report.Controls.Add(this.pnl_gap2);
            this.pnl_report.Controls.Add(this.button20);
            this.pnl_report.Controls.Add(this.button19);
            this.pnl_report.Controls.Add(this.button18);
            this.pnl_report.Controls.Add(this.button17);
            this.pnl_report.Controls.Add(this.button16);
            this.pnl_report.Controls.Add(this.button15);
            this.pnl_report.Controls.Add(this.button14);
            this.pnl_report.Controls.Add(this.button10);
            this.pnl_report.Controls.Add(this.button9);
            this.pnl_report.Controls.Add(this.pnl_gap1);
            this.pnl_report.Controls.Add(this.button11);
            this.pnl_report.Controls.Add(this.button12);
            this.pnl_report.Controls.Add(this.button13);
            this.bunifu_Ash.SetDecoration(this.pnl_report, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.pnl_report, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.pnl_report, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Sname.SetDecoration(this.pnl_report, BunifuAnimatorNS.DecorationType.None);
            this.pnl_report.Location = new System.Drawing.Point(862, 241);
            this.pnl_report.Name = "pnl_report";
            this.pnl_report.Size = new System.Drawing.Size(205, 491);
            this.pnl_report.TabIndex = 3;
            // 
            // button27
            // 
            this.button27.BackColor = System.Drawing.Color.White;
            this.Bunifu_Sname.SetDecoration(this.button27, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.button27, BunifuAnimatorNS.DecorationType.None);
            this.bunifu_Ash.SetDecoration(this.button27, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.button27, BunifuAnimatorNS.DecorationType.None);
            this.button27.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.button27.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.button27.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkGray;
            this.button27.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button27.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button27.ForeColor = System.Drawing.Color.Black;
            this.button27.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button27.Location = new System.Drawing.Point(0, 466);
            this.button27.Margin = new System.Windows.Forms.Padding(2);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(205, 25);
            this.button27.TabIndex = 27;
            this.button27.Text = "Short Excess Report";
            this.button27.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button27.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button27.UseVisualStyleBackColor = false;
            // 
            // button26
            // 
            this.button26.BackColor = System.Drawing.Color.White;
            this.Bunifu_Sname.SetDecoration(this.button26, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.button26, BunifuAnimatorNS.DecorationType.None);
            this.bunifu_Ash.SetDecoration(this.button26, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.button26, BunifuAnimatorNS.DecorationType.None);
            this.button26.Dock = System.Windows.Forms.DockStyle.Top;
            this.button26.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.button26.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkGray;
            this.button26.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button26.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button26.ForeColor = System.Drawing.Color.Black;
            this.button26.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button26.Location = new System.Drawing.Point(0, 441);
            this.button26.Margin = new System.Windows.Forms.Padding(2);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(205, 25);
            this.button26.TabIndex = 26;
            this.button26.Text = "Collection Report";
            this.button26.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button26.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button26.UseVisualStyleBackColor = false;
            // 
            // button25
            // 
            this.button25.BackColor = System.Drawing.Color.White;
            this.Bunifu_Sname.SetDecoration(this.button25, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.button25, BunifuAnimatorNS.DecorationType.None);
            this.bunifu_Ash.SetDecoration(this.button25, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.button25, BunifuAnimatorNS.DecorationType.None);
            this.button25.Dock = System.Windows.Forms.DockStyle.Top;
            this.button25.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.button25.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkGray;
            this.button25.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button25.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button25.ForeColor = System.Drawing.Color.Black;
            this.button25.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button25.Location = new System.Drawing.Point(0, 416);
            this.button25.Margin = new System.Windows.Forms.Padding(2);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(205, 25);
            this.button25.TabIndex = 25;
            this.button25.Text = "Loan Report";
            this.button25.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button25.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button25.UseVisualStyleBackColor = false;
            // 
            // pnl_gap4
            // 
            this.pnl_gap4.BackColor = System.Drawing.Color.Gray;
            this.bunifu_Ash.SetDecoration(this.pnl_gap4, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.pnl_gap4, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.pnl_gap4, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Sname.SetDecoration(this.pnl_gap4, BunifuAnimatorNS.DecorationType.None);
            this.pnl_gap4.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_gap4.Location = new System.Drawing.Point(0, 412);
            this.pnl_gap4.Name = "pnl_gap4";
            this.pnl_gap4.Size = new System.Drawing.Size(205, 4);
            this.pnl_gap4.TabIndex = 24;
            // 
            // btn_passbookChecking
            // 
            this.btn_passbookChecking.BackColor = System.Drawing.Color.White;
            this.Bunifu_Sname.SetDecoration(this.btn_passbookChecking, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.btn_passbookChecking, BunifuAnimatorNS.DecorationType.None);
            this.bunifu_Ash.SetDecoration(this.btn_passbookChecking, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.btn_passbookChecking, BunifuAnimatorNS.DecorationType.None);
            this.btn_passbookChecking.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_passbookChecking.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.btn_passbookChecking.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkGray;
            this.btn_passbookChecking.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_passbookChecking.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_passbookChecking.ForeColor = System.Drawing.Color.Black;
            this.btn_passbookChecking.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_passbookChecking.Location = new System.Drawing.Point(0, 387);
            this.btn_passbookChecking.Margin = new System.Windows.Forms.Padding(2);
            this.btn_passbookChecking.Name = "btn_passbookChecking";
            this.btn_passbookChecking.Size = new System.Drawing.Size(205, 25);
            this.btn_passbookChecking.TabIndex = 23;
            this.btn_passbookChecking.Text = "Pass Book Checking";
            this.btn_passbookChecking.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_passbookChecking.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_passbookChecking.UseVisualStyleBackColor = false;
            // 
            // pnl_gap3
            // 
            this.pnl_gap3.BackColor = System.Drawing.Color.Gray;
            this.bunifu_Ash.SetDecoration(this.pnl_gap3, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.pnl_gap3, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.pnl_gap3, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Sname.SetDecoration(this.pnl_gap3, BunifuAnimatorNS.DecorationType.None);
            this.pnl_gap3.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_gap3.Location = new System.Drawing.Point(0, 383);
            this.pnl_gap3.Name = "pnl_gap3";
            this.pnl_gap3.Size = new System.Drawing.Size(205, 4);
            this.pnl_gap3.TabIndex = 22;
            // 
            // button23
            // 
            this.button23.BackColor = System.Drawing.Color.White;
            this.Bunifu_Sname.SetDecoration(this.button23, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.button23, BunifuAnimatorNS.DecorationType.None);
            this.bunifu_Ash.SetDecoration(this.button23, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.button23, BunifuAnimatorNS.DecorationType.None);
            this.button23.Dock = System.Windows.Forms.DockStyle.Top;
            this.button23.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.button23.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkGray;
            this.button23.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button23.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button23.ForeColor = System.Drawing.Color.Black;
            this.button23.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button23.Location = new System.Drawing.Point(0, 358);
            this.button23.Margin = new System.Windows.Forms.Padding(2);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(205, 25);
            this.button23.TabIndex = 21;
            this.button23.Text = "Missing Numbers";
            this.button23.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button23.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button23.UseVisualStyleBackColor = false;
            // 
            // button22
            // 
            this.button22.BackColor = System.Drawing.Color.White;
            this.Bunifu_Sname.SetDecoration(this.button22, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.button22, BunifuAnimatorNS.DecorationType.None);
            this.bunifu_Ash.SetDecoration(this.button22, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.button22, BunifuAnimatorNS.DecorationType.None);
            this.button22.Dock = System.Windows.Forms.DockStyle.Top;
            this.button22.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.button22.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkGray;
            this.button22.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button22.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button22.ForeColor = System.Drawing.Color.Black;
            this.button22.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button22.Location = new System.Drawing.Point(0, 333);
            this.button22.Margin = new System.Windows.Forms.Padding(2);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(205, 25);
            this.button22.TabIndex = 20;
            this.button22.Text = "Pass Book (Collection Detail)";
            this.button22.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button22.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button22.UseVisualStyleBackColor = false;
            // 
            // button21
            // 
            this.button21.BackColor = System.Drawing.Color.White;
            this.Bunifu_Sname.SetDecoration(this.button21, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.button21, BunifuAnimatorNS.DecorationType.None);
            this.bunifu_Ash.SetDecoration(this.button21, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.button21, BunifuAnimatorNS.DecorationType.None);
            this.button21.Dock = System.Windows.Forms.DockStyle.Top;
            this.button21.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.button21.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkGray;
            this.button21.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button21.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button21.ForeColor = System.Drawing.Color.Black;
            this.button21.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button21.Location = new System.Drawing.Point(0, 308);
            this.button21.Margin = new System.Windows.Forms.Padding(2);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(205, 25);
            this.button21.TabIndex = 19;
            this.button21.Text = "Ledger (One party)";
            this.button21.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button21.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button21.UseVisualStyleBackColor = false;
            // 
            // pnl_gap2
            // 
            this.pnl_gap2.BackColor = System.Drawing.Color.Gray;
            this.bunifu_Ash.SetDecoration(this.pnl_gap2, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.pnl_gap2, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.pnl_gap2, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Sname.SetDecoration(this.pnl_gap2, BunifuAnimatorNS.DecorationType.None);
            this.pnl_gap2.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_gap2.Location = new System.Drawing.Point(0, 304);
            this.pnl_gap2.Name = "pnl_gap2";
            this.pnl_gap2.Size = new System.Drawing.Size(205, 4);
            this.pnl_gap2.TabIndex = 18;
            // 
            // button20
            // 
            this.button20.BackColor = System.Drawing.Color.White;
            this.Bunifu_Sname.SetDecoration(this.button20, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.button20, BunifuAnimatorNS.DecorationType.None);
            this.bunifu_Ash.SetDecoration(this.button20, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.button20, BunifuAnimatorNS.DecorationType.None);
            this.button20.Dock = System.Windows.Forms.DockStyle.Top;
            this.button20.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.button20.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkGray;
            this.button20.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button20.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button20.ForeColor = System.Drawing.Color.Black;
            this.button20.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button20.Location = new System.Drawing.Point(0, 279);
            this.button20.Margin = new System.Windows.Forms.Padding(2);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(205, 25);
            this.button20.TabIndex = 17;
            this.button20.Text = "Over Due";
            this.button20.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button20.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button20.UseVisualStyleBackColor = false;
            // 
            // button19
            // 
            this.button19.BackColor = System.Drawing.Color.White;
            this.Bunifu_Sname.SetDecoration(this.button19, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.button19, BunifuAnimatorNS.DecorationType.None);
            this.bunifu_Ash.SetDecoration(this.button19, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.button19, BunifuAnimatorNS.DecorationType.None);
            this.button19.Dock = System.Windows.Forms.DockStyle.Top;
            this.button19.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.button19.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkGray;
            this.button19.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button19.ForeColor = System.Drawing.Color.Black;
            this.button19.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button19.Location = new System.Drawing.Point(0, 254);
            this.button19.Margin = new System.Windows.Forms.Padding(2);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(205, 25);
            this.button19.TabIndex = 16;
            this.button19.Text = "Pending Partities";
            this.button19.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button19.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button19.UseVisualStyleBackColor = false;
            // 
            // button18
            // 
            this.button18.BackColor = System.Drawing.Color.White;
            this.Bunifu_Sname.SetDecoration(this.button18, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.button18, BunifuAnimatorNS.DecorationType.None);
            this.bunifu_Ash.SetDecoration(this.button18, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.button18, BunifuAnimatorNS.DecorationType.None);
            this.button18.Dock = System.Windows.Forms.DockStyle.Top;
            this.button18.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.button18.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkGray;
            this.button18.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button18.ForeColor = System.Drawing.Color.Black;
            this.button18.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button18.Location = new System.Drawing.Point(0, 229);
            this.button18.Margin = new System.Windows.Forms.Padding(2);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(205, 25);
            this.button18.TabIndex = 15;
            this.button18.Text = "No Pending Ledger";
            this.button18.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button18.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button18.UseVisualStyleBackColor = false;
            // 
            // button17
            // 
            this.button17.BackColor = System.Drawing.Color.White;
            this.Bunifu_Sname.SetDecoration(this.button17, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.button17, BunifuAnimatorNS.DecorationType.None);
            this.bunifu_Ash.SetDecoration(this.button17, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.button17, BunifuAnimatorNS.DecorationType.None);
            this.button17.Dock = System.Windows.Forms.DockStyle.Top;
            this.button17.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.button17.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkGray;
            this.button17.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button17.ForeColor = System.Drawing.Color.Black;
            this.button17.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button17.Location = new System.Drawing.Point(0, 204);
            this.button17.Margin = new System.Windows.Forms.Padding(2);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(205, 25);
            this.button17.TabIndex = 14;
            this.button17.Text = "Over 100 days members";
            this.button17.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button17.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button17.UseVisualStyleBackColor = false;
            // 
            // button16
            // 
            this.button16.BackColor = System.Drawing.Color.White;
            this.Bunifu_Sname.SetDecoration(this.button16, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.button16, BunifuAnimatorNS.DecorationType.None);
            this.bunifu_Ash.SetDecoration(this.button16, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.button16, BunifuAnimatorNS.DecorationType.None);
            this.button16.Dock = System.Windows.Forms.DockStyle.Top;
            this.button16.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.button16.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkGray;
            this.button16.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button16.ForeColor = System.Drawing.Color.Black;
            this.button16.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button16.Location = new System.Drawing.Point(0, 179);
            this.button16.Margin = new System.Windows.Forms.Padding(2);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(205, 25);
            this.button16.TabIndex = 13;
            this.button16.Text = "All Party Balance (Loan wise)";
            this.button16.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button16.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button16.UseVisualStyleBackColor = false;
            // 
            // button15
            // 
            this.button15.BackColor = System.Drawing.Color.White;
            this.Bunifu_Sname.SetDecoration(this.button15, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.button15, BunifuAnimatorNS.DecorationType.None);
            this.bunifu_Ash.SetDecoration(this.button15, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.button15, BunifuAnimatorNS.DecorationType.None);
            this.button15.Dock = System.Windows.Forms.DockStyle.Top;
            this.button15.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.button15.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkGray;
            this.button15.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button15.ForeColor = System.Drawing.Color.Black;
            this.button15.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button15.Location = new System.Drawing.Point(0, 154);
            this.button15.Margin = new System.Windows.Forms.Padding(2);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(205, 25);
            this.button15.TabIndex = 12;
            this.button15.Text = "All Party Balance Only";
            this.button15.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button15.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button15.UseVisualStyleBackColor = false;
            // 
            // button14
            // 
            this.button14.BackColor = System.Drawing.Color.White;
            this.Bunifu_Sname.SetDecoration(this.button14, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.button14, BunifuAnimatorNS.DecorationType.None);
            this.bunifu_Ash.SetDecoration(this.button14, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.button14, BunifuAnimatorNS.DecorationType.None);
            this.button14.Dock = System.Windows.Forms.DockStyle.Top;
            this.button14.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.button14.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkGray;
            this.button14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button14.ForeColor = System.Drawing.Color.Black;
            this.button14.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button14.Location = new System.Drawing.Point(0, 129);
            this.button14.Margin = new System.Windows.Forms.Padding(2);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(205, 25);
            this.button14.TabIndex = 11;
            this.button14.Text = "All Party Net (Less Amt)";
            this.button14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button14.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button14.UseVisualStyleBackColor = false;
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.Color.White;
            this.Bunifu_Sname.SetDecoration(this.button10, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.button10, BunifuAnimatorNS.DecorationType.None);
            this.bunifu_Ash.SetDecoration(this.button10, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.button10, BunifuAnimatorNS.DecorationType.None);
            this.button10.Dock = System.Windows.Forms.DockStyle.Top;
            this.button10.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.button10.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkGray;
            this.button10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button10.ForeColor = System.Drawing.Color.Black;
            this.button10.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button10.Location = new System.Drawing.Point(0, 104);
            this.button10.Margin = new System.Windows.Forms.Padding(2);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(205, 25);
            this.button10.TabIndex = 10;
            this.button10.Text = "All Party Net (Excess Amt)";
            this.button10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button10.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button10.UseVisualStyleBackColor = false;
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.White;
            this.Bunifu_Sname.SetDecoration(this.button9, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.button9, BunifuAnimatorNS.DecorationType.None);
            this.bunifu_Ash.SetDecoration(this.button9, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.button9, BunifuAnimatorNS.DecorationType.None);
            this.button9.Dock = System.Windows.Forms.DockStyle.Top;
            this.button9.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.button9.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkGray;
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button9.ForeColor = System.Drawing.Color.Black;
            this.button9.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button9.Location = new System.Drawing.Point(0, 79);
            this.button9.Margin = new System.Windows.Forms.Padding(2);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(205, 25);
            this.button9.TabIndex = 9;
            this.button9.Text = "All Party Balance (Net)";
            this.button9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button9.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button9.UseVisualStyleBackColor = false;
            // 
            // pnl_gap1
            // 
            this.pnl_gap1.BackColor = System.Drawing.Color.Gray;
            this.bunifu_Ash.SetDecoration(this.pnl_gap1, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.pnl_gap1, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.pnl_gap1, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Sname.SetDecoration(this.pnl_gap1, BunifuAnimatorNS.DecorationType.None);
            this.pnl_gap1.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_gap1.Location = new System.Drawing.Point(0, 75);
            this.pnl_gap1.Name = "pnl_gap1";
            this.pnl_gap1.Size = new System.Drawing.Size(205, 4);
            this.pnl_gap1.TabIndex = 8;
            // 
            // button11
            // 
            this.button11.BackColor = System.Drawing.Color.White;
            this.Bunifu_Sname.SetDecoration(this.button11, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.button11, BunifuAnimatorNS.DecorationType.None);
            this.bunifu_Ash.SetDecoration(this.button11, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.button11, BunifuAnimatorNS.DecorationType.None);
            this.button11.Dock = System.Windows.Forms.DockStyle.Top;
            this.button11.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.button11.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkGray;
            this.button11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button11.ForeColor = System.Drawing.Color.Black;
            this.button11.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button11.Location = new System.Drawing.Point(0, 50);
            this.button11.Margin = new System.Windows.Forms.Padding(2);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(205, 25);
            this.button11.TabIndex = 7;
            this.button11.Text = "Summary";
            this.button11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button11.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button11.UseVisualStyleBackColor = false;
            // 
            // button12
            // 
            this.button12.BackColor = System.Drawing.Color.White;
            this.Bunifu_Sname.SetDecoration(this.button12, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.button12, BunifuAnimatorNS.DecorationType.None);
            this.bunifu_Ash.SetDecoration(this.button12, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.button12, BunifuAnimatorNS.DecorationType.None);
            this.button12.Dock = System.Windows.Forms.DockStyle.Top;
            this.button12.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.button12.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkGray;
            this.button12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button12.ForeColor = System.Drawing.Color.Black;
            this.button12.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button12.Location = new System.Drawing.Point(0, 25);
            this.button12.Margin = new System.Windows.Forms.Padding(2);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(205, 25);
            this.button12.TabIndex = 6;
            this.button12.Text = "Outstanding";
            this.button12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button12.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button12.UseVisualStyleBackColor = false;
            // 
            // button13
            // 
            this.button13.BackColor = System.Drawing.Color.White;
            this.Bunifu_Sname.SetDecoration(this.button13, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.button13, BunifuAnimatorNS.DecorationType.None);
            this.bunifu_Ash.SetDecoration(this.button13, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.button13, BunifuAnimatorNS.DecorationType.None);
            this.button13.Dock = System.Windows.Forms.DockStyle.Top;
            this.button13.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.button13.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkGray;
            this.button13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button13.ForeColor = System.Drawing.Color.Black;
            this.button13.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button13.Location = new System.Drawing.Point(0, 0);
            this.button13.Margin = new System.Windows.Forms.Padding(2);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(205, 25);
            this.button13.TabIndex = 5;
            this.button13.Text = "Collection";
            this.button13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button13.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button13.UseVisualStyleBackColor = false;
            // 
            // pnl_file
            // 
            this.pnl_file.BackColor = System.Drawing.Color.White;
            this.pnl_file.Controls.Add(this.button8);
            this.pnl_file.Controls.Add(this.button6);
            this.pnl_file.Controls.Add(this.button7);
            this.bunifu_Ash.SetDecoration(this.pnl_file, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.pnl_file, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.pnl_file, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Sname.SetDecoration(this.pnl_file, BunifuAnimatorNS.DecorationType.None);
            this.pnl_file.Location = new System.Drawing.Point(290, 281);
            this.pnl_file.Name = "pnl_file";
            this.pnl_file.Size = new System.Drawing.Size(131, 90);
            this.pnl_file.TabIndex = 2;
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.White;
            this.Bunifu_Sname.SetDecoration(this.button8, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.button8, BunifuAnimatorNS.DecorationType.None);
            this.bunifu_Ash.SetDecoration(this.button8, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.button8, BunifuAnimatorNS.DecorationType.None);
            this.button8.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.button8.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.button8.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkGray;
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8.ForeColor = System.Drawing.Color.Black;
            this.button8.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button8.Location = new System.Drawing.Point(0, 30);
            this.button8.Margin = new System.Windows.Forms.Padding(2);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(131, 30);
            this.button8.TabIndex = 7;
            this.button8.Text = "Login";
            this.button8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button8.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button8.UseVisualStyleBackColor = false;
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.White;
            this.Bunifu_Sname.SetDecoration(this.button6, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.button6, BunifuAnimatorNS.DecorationType.None);
            this.bunifu_Ash.SetDecoration(this.button6, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.button6, BunifuAnimatorNS.DecorationType.None);
            this.button6.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.button6.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.button6.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkGray;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.ForeColor = System.Drawing.Color.Black;
            this.button6.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button6.Location = new System.Drawing.Point(0, 60);
            this.button6.Margin = new System.Windows.Forms.Padding(2);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(131, 30);
            this.button6.TabIndex = 6;
            this.button6.Text = "Exit";
            this.button6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button6.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button6.UseVisualStyleBackColor = false;
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.White;
            this.Bunifu_Sname.SetDecoration(this.button7, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.button7, BunifuAnimatorNS.DecorationType.None);
            this.bunifu_Ash.SetDecoration(this.button7, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.button7, BunifuAnimatorNS.DecorationType.None);
            this.button7.Dock = System.Windows.Forms.DockStyle.Top;
            this.button7.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.button7.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkGray;
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.ForeColor = System.Drawing.Color.Black;
            this.button7.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button7.Location = new System.Drawing.Point(0, 0);
            this.button7.Margin = new System.Windows.Forms.Padding(2);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(131, 30);
            this.button7.TabIndex = 5;
            this.button7.Text = "Company";
            this.button7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button7.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button7.UseVisualStyleBackColor = false;
            // 
            // pnl_master
            // 
            this.pnl_master.BackColor = System.Drawing.Color.White;
            this.pnl_master.Controls.Add(this.button5);
            this.pnl_master.Controls.Add(this.button4);
            this.pnl_master.Controls.Add(this.button3);
            this.pnl_master.Controls.Add(this.button1);
            this.pnl_master.Controls.Add(this.button2);
            this.bunifu_Ash.SetDecoration(this.pnl_master, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.pnl_master, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.pnl_master, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Sname.SetDecoration(this.pnl_master, BunifuAnimatorNS.DecorationType.None);
            this.pnl_master.Location = new System.Drawing.Point(457, 241);
            this.pnl_master.Name = "pnl_master";
            this.pnl_master.Size = new System.Drawing.Size(147, 152);
            this.pnl_master.TabIndex = 1;
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.White;
            this.Bunifu_Sname.SetDecoration(this.button5, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.button5, BunifuAnimatorNS.DecorationType.None);
            this.bunifu_Ash.SetDecoration(this.button5, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.button5, BunifuAnimatorNS.DecorationType.None);
            this.button5.Dock = System.Windows.Forms.DockStyle.Top;
            this.button5.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.button5.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkGray;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.ForeColor = System.Drawing.Color.Black;
            this.button5.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button5.Location = new System.Drawing.Point(0, 120);
            this.button5.Margin = new System.Windows.Forms.Padding(2);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(147, 32);
            this.button5.TabIndex = 9;
            this.button5.Text = "Member Group";
            this.button5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button5.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button5.UseVisualStyleBackColor = false;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.White;
            this.Bunifu_Sname.SetDecoration(this.button4, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.button4, BunifuAnimatorNS.DecorationType.None);
            this.bunifu_Ash.SetDecoration(this.button4, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.button4, BunifuAnimatorNS.DecorationType.None);
            this.button4.Dock = System.Windows.Forms.DockStyle.Top;
            this.button4.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.button4.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkGray;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.Color.Black;
            this.button4.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button4.Location = new System.Drawing.Point(0, 90);
            this.button4.Margin = new System.Windows.Forms.Padding(2);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(147, 30);
            this.button4.TabIndex = 8;
            this.button4.Text = "Street";
            this.button4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button4.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button4.UseVisualStyleBackColor = false;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.White;
            this.Bunifu_Sname.SetDecoration(this.button3, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.button3, BunifuAnimatorNS.DecorationType.None);
            this.bunifu_Ash.SetDecoration(this.button3, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.button3, BunifuAnimatorNS.DecorationType.None);
            this.button3.Dock = System.Windows.Forms.DockStyle.Top;
            this.button3.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.button3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkGray;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.Black;
            this.button3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button3.Location = new System.Drawing.Point(0, 60);
            this.button3.Margin = new System.Windows.Forms.Padding(2);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(147, 30);
            this.button3.TabIndex = 7;
            this.button3.Text = "Party Detail";
            this.button3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button3.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button3.UseVisualStyleBackColor = false;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.White;
            this.Bunifu_Sname.SetDecoration(this.button1, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.button1, BunifuAnimatorNS.DecorationType.None);
            this.bunifu_Ash.SetDecoration(this.button1, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.button1, BunifuAnimatorNS.DecorationType.None);
            this.button1.Dock = System.Windows.Forms.DockStyle.Top;
            this.button1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkGray;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.Black;
            this.button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.Location = new System.Drawing.Point(0, 30);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(147, 30);
            this.button1.TabIndex = 6;
            this.button1.Text = "Ledger Report";
            this.button1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button1.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.White;
            this.Bunifu_Sname.SetDecoration(this.button2, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.button2, BunifuAnimatorNS.DecorationType.None);
            this.bunifu_Ash.SetDecoration(this.button2, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.button2, BunifuAnimatorNS.DecorationType.None);
            this.button2.Dock = System.Windows.Forms.DockStyle.Top;
            this.button2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.button2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkGray;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.Black;
            this.button2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button2.Location = new System.Drawing.Point(0, 0);
            this.button2.Margin = new System.Windows.Forms.Padding(2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(147, 30);
            this.button2.TabIndex = 5;
            this.button2.Text = "Member";
            this.button2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button2.UseVisualStyleBackColor = false;
            // 
            // pnl_entry
            // 
            this.pnl_entry.BackColor = System.Drawing.Color.White;
            this.pnl_entry.Controls.Add(this.btn_collection);
            this.pnl_entry.Controls.Add(this.btn_loan);
            this.bunifu_Ash.SetDecoration(this.pnl_entry, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.pnl_entry, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.pnl_entry, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Sname.SetDecoration(this.pnl_entry, BunifuAnimatorNS.DecorationType.None);
            this.pnl_entry.Location = new System.Drawing.Point(476, 421);
            this.pnl_entry.Name = "pnl_entry";
            this.pnl_entry.Size = new System.Drawing.Size(128, 60);
            this.pnl_entry.TabIndex = 0;
            // 
            // btn_collection
            // 
            this.btn_collection.BackColor = System.Drawing.Color.White;
            this.Bunifu_Sname.SetDecoration(this.btn_collection, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.btn_collection, BunifuAnimatorNS.DecorationType.None);
            this.bunifu_Ash.SetDecoration(this.btn_collection, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.btn_collection, BunifuAnimatorNS.DecorationType.None);
            this.btn_collection.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_collection.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.btn_collection.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkGray;
            this.btn_collection.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_collection.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_collection.ForeColor = System.Drawing.Color.Black;
            this.btn_collection.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_collection.Location = new System.Drawing.Point(0, 30);
            this.btn_collection.Margin = new System.Windows.Forms.Padding(2);
            this.btn_collection.Name = "btn_collection";
            this.btn_collection.Size = new System.Drawing.Size(128, 30);
            this.btn_collection.TabIndex = 6;
            this.btn_collection.Text = "Collection";
            this.btn_collection.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_collection.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_collection.UseVisualStyleBackColor = false;
            // 
            // btn_loan
            // 
            this.btn_loan.BackColor = System.Drawing.Color.White;
            this.Bunifu_Sname.SetDecoration(this.btn_loan, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.btn_loan, BunifuAnimatorNS.DecorationType.None);
            this.bunifu_Ash.SetDecoration(this.btn_loan, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.btn_loan, BunifuAnimatorNS.DecorationType.None);
            this.btn_loan.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_loan.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.btn_loan.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkGray;
            this.btn_loan.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_loan.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_loan.ForeColor = System.Drawing.Color.Black;
            this.btn_loan.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_loan.Location = new System.Drawing.Point(0, 0);
            this.btn_loan.Margin = new System.Windows.Forms.Padding(2);
            this.btn_loan.Name = "btn_loan";
            this.btn_loan.Size = new System.Drawing.Size(128, 30);
            this.btn_loan.TabIndex = 5;
            this.btn_loan.Text = "Loan";
            this.btn_loan.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_loan.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_loan.UseVisualStyleBackColor = false;
            // 
            // pnl_main
            // 
            this.bunifu_Ash.SetDecoration(this.pnl_main, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.pnl_main, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.pnl_main, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Sname.SetDecoration(this.pnl_main, BunifuAnimatorNS.DecorationType.None);
            this.pnl_main.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnl_main.Location = new System.Drawing.Point(0, 159);
            this.pnl_main.Name = "pnl_main";
            this.pnl_main.Size = new System.Drawing.Size(1151, 628);
            this.pnl_main.TabIndex = 5;
            // 
            // tm_Time
            // 
            this.tm_Time.Tick += new System.EventHandler(this.tm_Time_Tick);
            // 
            // pnl_title
            // 
            this.pnl_title.BackColor = System.Drawing.Color.Bisque;
            this.pnl_title.Controls.Add(this.btn_min);
            this.pnl_title.Controls.Add(this.lbl_headAsh);
            this.pnl_title.Controls.Add(this.btn_exit);
            this.bunifu_Ash.SetDecoration(this.pnl_title, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.pnl_title, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.pnl_title, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Sname.SetDecoration(this.pnl_title, BunifuAnimatorNS.DecorationType.None);
            this.pnl_title.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_title.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.pnl_title.Location = new System.Drawing.Point(235, 0);
            this.pnl_title.Margin = new System.Windows.Forms.Padding(2);
            this.pnl_title.Name = "pnl_title";
            this.pnl_title.Size = new System.Drawing.Size(1151, 40);
            this.pnl_title.TabIndex = 11;
            // 
            // btn_min
            // 
            this.btn_min.BackColor = System.Drawing.Color.Gray;
            this.Bunifu_Sname.SetDecoration(this.btn_min, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.btn_min, BunifuAnimatorNS.DecorationType.None);
            this.bunifu_Ash.SetDecoration(this.btn_min, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.btn_min, BunifuAnimatorNS.DecorationType.None);
            this.btn_min.Dock = System.Windows.Forms.DockStyle.Right;
            this.btn_min.FlatAppearance.BorderSize = 0;
            this.btn_min.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.btn_min.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkGray;
            this.btn_min.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_min.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_min.ForeColor = System.Drawing.Color.White;
            this.btn_min.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_min.Location = new System.Drawing.Point(1067, 0);
            this.btn_min.Margin = new System.Windows.Forms.Padding(2);
            this.btn_min.Name = "btn_min";
            this.btn_min.Size = new System.Drawing.Size(44, 40);
            this.btn_min.TabIndex = 4;
            this.btn_min.Text = "_";
            this.btn_min.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_min.UseVisualStyleBackColor = false;
            this.btn_min.Click += new System.EventHandler(this.btn_min_Click);
            // 
            // lbl_headAsh
            // 
            this.lbl_headAsh.AutoSize = true;
            this.Bunifu_Sname.SetDecoration(this.lbl_headAsh, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.lbl_headAsh, BunifuAnimatorNS.DecorationType.None);
            this.bunifu_Ash.SetDecoration(this.lbl_headAsh, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.lbl_headAsh, BunifuAnimatorNS.DecorationType.None);
            this.lbl_headAsh.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_headAsh.ForeColor = System.Drawing.Color.OrangeRed;
            this.lbl_headAsh.Location = new System.Drawing.Point(4, 9);
            this.lbl_headAsh.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_headAsh.Name = "lbl_headAsh";
            this.lbl_headAsh.Size = new System.Drawing.Size(350, 25);
            this.lbl_headAsh.TabIndex = 0;
            this.lbl_headAsh.Text = "Finance Soft by Ash Developers";
            // 
            // btn_exit
            // 
            this.btn_exit.BackColor = System.Drawing.Color.Red;
            this.Bunifu_Sname.SetDecoration(this.btn_exit, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.btn_exit, BunifuAnimatorNS.DecorationType.None);
            this.bunifu_Ash.SetDecoration(this.btn_exit, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.btn_exit, BunifuAnimatorNS.DecorationType.None);
            this.btn_exit.Dock = System.Windows.Forms.DockStyle.Right;
            this.btn_exit.FlatAppearance.BorderSize = 0;
            this.btn_exit.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red;
            this.btn_exit.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Tomato;
            this.btn_exit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_exit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_exit.ForeColor = System.Drawing.Color.White;
            this.btn_exit.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_exit.Location = new System.Drawing.Point(1111, 0);
            this.btn_exit.Margin = new System.Windows.Forms.Padding(2);
            this.btn_exit.Name = "btn_exit";
            this.btn_exit.Size = new System.Drawing.Size(40, 40);
            this.btn_exit.TabIndex = 2;
            this.btn_exit.Text = "X";
            this.btn_exit.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_exit.UseVisualStyleBackColor = false;
            this.btn_exit.Click += new System.EventHandler(this.btn_exit_Click);
            // 
            // pnl_admin
            // 
            this.pnl_admin.BackColor = System.Drawing.Color.SandyBrown;
            this.pnl_admin.Controls.Add(this.pnl_outTime);
            this.pnl_admin.Controls.Add(this.lbl_usertype);
            this.pnl_admin.Controls.Add(this.lbl_role);
            this.pnl_admin.Controls.Add(this.lbl_user);
            this.pnl_admin.Controls.Add(this.lbl_welcome);
            this.bunifu_Ash.SetDecoration(this.pnl_admin, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.pnl_admin, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.pnl_admin, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Sname.SetDecoration(this.pnl_admin, BunifuAnimatorNS.DecorationType.None);
            this.pnl_admin.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_admin.Location = new System.Drawing.Point(235, 40);
            this.pnl_admin.Margin = new System.Windows.Forms.Padding(2);
            this.pnl_admin.Name = "pnl_admin";
            this.pnl_admin.Size = new System.Drawing.Size(1151, 114);
            this.pnl_admin.TabIndex = 12;
            // 
            // pnl_outTime
            // 
            this.pnl_outTime.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pnl_outTime.BackColor = System.Drawing.Color.Gray;
            this.pnl_outTime.Controls.Add(this.pnl_inTime);
            this.bunifu_Ash.SetDecoration(this.pnl_outTime, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.pnl_outTime, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.pnl_outTime, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Sname.SetDecoration(this.pnl_outTime, BunifuAnimatorNS.DecorationType.None);
            this.pnl_outTime.Location = new System.Drawing.Point(871, 22);
            this.pnl_outTime.Margin = new System.Windows.Forms.Padding(2);
            this.pnl_outTime.Name = "pnl_outTime";
            this.pnl_outTime.Size = new System.Drawing.Size(262, 73);
            this.pnl_outTime.TabIndex = 2;
            // 
            // pnl_inTime
            // 
            this.pnl_inTime.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pnl_inTime.BackColor = System.Drawing.Color.Black;
            this.pnl_inTime.Controls.Add(this.lbl_day);
            this.pnl_inTime.Controls.Add(this.lbl_time);
            this.bunifu_Ash.SetDecoration(this.pnl_inTime, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.pnl_inTime, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.pnl_inTime, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Sname.SetDecoration(this.pnl_inTime, BunifuAnimatorNS.DecorationType.None);
            this.pnl_inTime.Location = new System.Drawing.Point(14, 10);
            this.pnl_inTime.Margin = new System.Windows.Forms.Padding(2);
            this.pnl_inTime.Name = "pnl_inTime";
            this.pnl_inTime.Size = new System.Drawing.Size(235, 52);
            this.pnl_inTime.TabIndex = 0;
            // 
            // lbl_day
            // 
            this.lbl_day.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_day.AutoSize = true;
            this.Bunifu_Sname.SetDecoration(this.lbl_day, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.lbl_day, BunifuAnimatorNS.DecorationType.None);
            this.bunifu_Ash.SetDecoration(this.lbl_day, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.lbl_day, BunifuAnimatorNS.DecorationType.None);
            this.lbl_day.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_day.ForeColor = System.Drawing.Color.SeaGreen;
            this.lbl_day.Location = new System.Drawing.Point(10, 4);
            this.lbl_day.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_day.Name = "lbl_day";
            this.lbl_day.Size = new System.Drawing.Size(212, 24);
            this.lbl_day.TabIndex = 1;
            this.lbl_day.Text = "DDDDD DD/MM/YYYY";
            // 
            // lbl_time
            // 
            this.lbl_time.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_time.AutoSize = true;
            this.Bunifu_Sname.SetDecoration(this.lbl_time, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.lbl_time, BunifuAnimatorNS.DecorationType.None);
            this.bunifu_Ash.SetDecoration(this.lbl_time, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.lbl_time, BunifuAnimatorNS.DecorationType.None);
            this.lbl_time.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_time.ForeColor = System.Drawing.Color.Red;
            this.lbl_time.Location = new System.Drawing.Point(45, 26);
            this.lbl_time.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_time.Name = "lbl_time";
            this.lbl_time.Size = new System.Drawing.Size(144, 24);
            this.lbl_time.TabIndex = 0;
            this.lbl_time.Text = "HH:MM:SS TT";
            // 
            // lbl_usertype
            // 
            this.lbl_usertype.AutoSize = true;
            this.Bunifu_Sname.SetDecoration(this.lbl_usertype, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.lbl_usertype, BunifuAnimatorNS.DecorationType.None);
            this.bunifu_Ash.SetDecoration(this.lbl_usertype, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.lbl_usertype, BunifuAnimatorNS.DecorationType.None);
            this.lbl_usertype.Font = new System.Drawing.Font("Segoe Print", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_usertype.ForeColor = System.Drawing.Color.White;
            this.lbl_usertype.Location = new System.Drawing.Point(132, 54);
            this.lbl_usertype.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_usertype.Name = "lbl_usertype";
            this.lbl_usertype.Size = new System.Drawing.Size(88, 37);
            this.lbl_usertype.TabIndex = 0;
            this.lbl_usertype.Text = "Admin";
            // 
            // lbl_role
            // 
            this.lbl_role.AutoSize = true;
            this.Bunifu_Sname.SetDecoration(this.lbl_role, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.lbl_role, BunifuAnimatorNS.DecorationType.None);
            this.bunifu_Ash.SetDecoration(this.lbl_role, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.lbl_role, BunifuAnimatorNS.DecorationType.None);
            this.lbl_role.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_role.ForeColor = System.Drawing.Color.White;
            this.lbl_role.Location = new System.Drawing.Point(24, 60);
            this.lbl_role.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_role.Name = "lbl_role";
            this.lbl_role.Size = new System.Drawing.Size(67, 25);
            this.lbl_role.TabIndex = 0;
            this.lbl_role.Text = "Role:";
            // 
            // lbl_user
            // 
            this.lbl_user.AutoSize = true;
            this.Bunifu_Sname.SetDecoration(this.lbl_user, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.lbl_user, BunifuAnimatorNS.DecorationType.None);
            this.bunifu_Ash.SetDecoration(this.lbl_user, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.lbl_user, BunifuAnimatorNS.DecorationType.None);
            this.lbl_user.Font = new System.Drawing.Font("Segoe Print", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_user.ForeColor = System.Drawing.Color.White;
            this.lbl_user.Location = new System.Drawing.Point(132, 24);
            this.lbl_user.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_user.Name = "lbl_user";
            this.lbl_user.Size = new System.Drawing.Size(170, 37);
            this.lbl_user.TabIndex = 0;
            this.lbl_user.Text = "AsHfaQ NaInA";
            // 
            // lbl_welcome
            // 
            this.lbl_welcome.AutoSize = true;
            this.Bunifu_Sname.SetDecoration(this.lbl_welcome, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.lbl_welcome, BunifuAnimatorNS.DecorationType.None);
            this.bunifu_Ash.SetDecoration(this.lbl_welcome, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.lbl_welcome, BunifuAnimatorNS.DecorationType.None);
            this.lbl_welcome.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_welcome.ForeColor = System.Drawing.Color.White;
            this.lbl_welcome.Location = new System.Drawing.Point(24, 29);
            this.lbl_welcome.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_welcome.Name = "lbl_welcome";
            this.lbl_welcome.Size = new System.Drawing.Size(115, 25);
            this.lbl_welcome.TabIndex = 0;
            this.lbl_welcome.Text = "Welcome:";
            // 
            // pnl_Lefttop
            // 
            this.pnl_Lefttop.Controls.Add(this.lbl_ash);
            this.pnl_Lefttop.Controls.Add(this.btn_slide);
            this.pnl_Lefttop.Controls.Add(this.lbl_soft);
            this.pnl_Lefttop.Controls.Add(this.pb_logo);
            this.bunifu_Ash.SetDecoration(this.pnl_Lefttop, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.pnl_Lefttop, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.pnl_Lefttop, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Sname.SetDecoration(this.pnl_Lefttop, BunifuAnimatorNS.DecorationType.None);
            this.pnl_Lefttop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_Lefttop.Location = new System.Drawing.Point(0, 0);
            this.pnl_Lefttop.Margin = new System.Windows.Forms.Padding(2);
            this.pnl_Lefttop.Name = "pnl_Lefttop";
            this.pnl_Lefttop.Size = new System.Drawing.Size(235, 154);
            this.pnl_Lefttop.TabIndex = 0;
            // 
            // lbl_ash
            // 
            this.lbl_ash.AutoSize = true;
            this.Bunifu_Sname.SetDecoration(this.lbl_ash, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.lbl_ash, BunifuAnimatorNS.DecorationType.None);
            this.bunifu_Ash.SetDecoration(this.lbl_ash, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.lbl_ash, BunifuAnimatorNS.DecorationType.None);
            this.lbl_ash.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ash.ForeColor = System.Drawing.Color.White;
            this.lbl_ash.Location = new System.Drawing.Point(64, 128);
            this.lbl_ash.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_ash.Name = "lbl_ash";
            this.lbl_ash.Size = new System.Drawing.Size(126, 18);
            this.lbl_ash.TabIndex = 0;
            this.lbl_ash.Text = "Ash Developers";
            // 
            // btn_slide
            // 
            this.btn_slide.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Bunifu_Sname.SetDecoration(this.btn_slide, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.btn_slide, BunifuAnimatorNS.DecorationType.None);
            this.bunifu_Ash.SetDecoration(this.btn_slide, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.btn_slide, BunifuAnimatorNS.DecorationType.None);
            this.btn_slide.FlatAppearance.BorderSize = 0;
            this.btn_slide.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_slide.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_slide.ForeColor = System.Drawing.Color.White;
            this.btn_slide.Image = ((System.Drawing.Image)(resources.GetObject("btn_slide.Image")));
            this.btn_slide.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_slide.Location = new System.Drawing.Point(187, 1);
            this.btn_slide.Margin = new System.Windows.Forms.Padding(2);
            this.btn_slide.Name = "btn_slide";
            this.btn_slide.Size = new System.Drawing.Size(41, 37);
            this.btn_slide.TabIndex = 2;
            this.btn_slide.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_slide.UseVisualStyleBackColor = true;
            this.btn_slide.Click += new System.EventHandler(this.btn_slide_Click);
            // 
            // lbl_soft
            // 
            this.lbl_soft.AutoSize = true;
            this.Bunifu_Sname.SetDecoration(this.lbl_soft, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.lbl_soft, BunifuAnimatorNS.DecorationType.None);
            this.bunifu_Ash.SetDecoration(this.lbl_soft, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.lbl_soft, BunifuAnimatorNS.DecorationType.None);
            this.lbl_soft.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_soft.ForeColor = System.Drawing.Color.White;
            this.lbl_soft.Location = new System.Drawing.Point(55, 102);
            this.lbl_soft.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_soft.Name = "lbl_soft";
            this.lbl_soft.Size = new System.Drawing.Size(145, 25);
            this.lbl_soft.TabIndex = 0;
            this.lbl_soft.Text = "Finance Soft";
            // 
            // pb_logo
            // 
            this.Bunifu_Sname.SetDecoration(this.pb_logo, BunifuAnimatorNS.DecorationType.None);
            this.bunifu_Ash.SetDecoration(this.pb_logo, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.pb_logo, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.pb_logo, BunifuAnimatorNS.DecorationType.None);
            this.pb_logo.Image = global::Finance.Properties.Resources.Finance;
            this.pb_logo.Location = new System.Drawing.Point(98, 39);
            this.pb_logo.Margin = new System.Windows.Forms.Padding(2);
            this.pb_logo.Name = "pb_logo";
            this.pb_logo.Size = new System.Drawing.Size(57, 57);
            this.pb_logo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_logo.TabIndex = 2;
            this.pb_logo.TabStop = false;
            // 
            // pnl_slide
            // 
            this.pnl_slide.BackColor = System.Drawing.Color.White;
            this.bunifu_Ash.SetDecoration(this.pnl_slide, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.pnl_slide, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.pnl_slide, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Sname.SetDecoration(this.pnl_slide, BunifuAnimatorNS.DecorationType.None);
            this.pnl_slide.Location = new System.Drawing.Point(1, 169);
            this.pnl_slide.Margin = new System.Windows.Forms.Padding(2);
            this.pnl_slide.Name = "pnl_slide";
            this.pnl_slide.Size = new System.Drawing.Size(6, 55);
            this.pnl_slide.TabIndex = 1;
            // 
            // pnl_Left
            // 
            this.pnl_Left.BackColor = System.Drawing.Color.Coral;
            this.pnl_Left.Controls.Add(this.btn_report);
            this.pnl_Left.Controls.Add(this.btn_mail);
            this.pnl_Left.Controls.Add(this.btn_about);
            this.pnl_Left.Controls.Add(this.btn_file);
            this.pnl_Left.Controls.Add(this.pnl_slide);
            this.pnl_Left.Controls.Add(this.btn_entry);
            this.pnl_Left.Controls.Add(this.btn_admin);
            this.pnl_Left.Controls.Add(this.btn_master);
            this.pnl_Left.Controls.Add(this.pnl_Lefttop);
            this.bunifu_Ash.SetDecoration(this.pnl_Left, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.pnl_Left, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.pnl_Left, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Sname.SetDecoration(this.pnl_Left, BunifuAnimatorNS.DecorationType.None);
            this.pnl_Left.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnl_Left.Location = new System.Drawing.Point(0, 0);
            this.pnl_Left.Margin = new System.Windows.Forms.Padding(2);
            this.pnl_Left.Name = "pnl_Left";
            this.pnl_Left.Size = new System.Drawing.Size(235, 787);
            this.pnl_Left.TabIndex = 8;
            // 
            // btn_report
            // 
            this.Bunifu_Sname.SetDecoration(this.btn_report, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.btn_report, BunifuAnimatorNS.DecorationType.None);
            this.bunifu_Ash.SetDecoration(this.btn_report, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.btn_report, BunifuAnimatorNS.DecorationType.None);
            this.btn_report.FlatAppearance.BorderSize = 0;
            this.btn_report.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_report.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_report.ForeColor = System.Drawing.Color.White;
            this.btn_report.Image = ((System.Drawing.Image)(resources.GetObject("btn_report.Image")));
            this.btn_report.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_report.Location = new System.Drawing.Point(11, 287);
            this.btn_report.Margin = new System.Windows.Forms.Padding(2);
            this.btn_report.Name = "btn_report";
            this.btn_report.Size = new System.Drawing.Size(221, 55);
            this.btn_report.TabIndex = 6;
            this.btn_report.Text = "     Report";
            this.btn_report.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_report.UseVisualStyleBackColor = true;
            this.btn_report.Click += new System.EventHandler(this.btn_report_Click);
            // 
            // btn_mail
            // 
            this.Bunifu_Sname.SetDecoration(this.btn_mail, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.btn_mail, BunifuAnimatorNS.DecorationType.None);
            this.bunifu_Ash.SetDecoration(this.btn_mail, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.btn_mail, BunifuAnimatorNS.DecorationType.None);
            this.btn_mail.FlatAppearance.BorderSize = 0;
            this.btn_mail.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_mail.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_mail.ForeColor = System.Drawing.Color.White;
            this.btn_mail.Image = global::Finance.Properties.Resources.mail;
            this.btn_mail.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_mail.Location = new System.Drawing.Point(9, 464);
            this.btn_mail.Margin = new System.Windows.Forms.Padding(2);
            this.btn_mail.Name = "btn_mail";
            this.btn_mail.Size = new System.Drawing.Size(221, 55);
            this.btn_mail.TabIndex = 5;
            this.btn_mail.Text = "     Mail Service";
            this.btn_mail.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_mail.UseVisualStyleBackColor = true;
            this.btn_mail.Click += new System.EventHandler(this.btn_mail_Click);
            // 
            // btn_about
            // 
            this.Bunifu_Sname.SetDecoration(this.btn_about, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.btn_about, BunifuAnimatorNS.DecorationType.None);
            this.bunifu_Ash.SetDecoration(this.btn_about, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.btn_about, BunifuAnimatorNS.DecorationType.None);
            this.btn_about.FlatAppearance.BorderSize = 0;
            this.btn_about.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_about.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_about.ForeColor = System.Drawing.Color.White;
            this.btn_about.Image = global::Finance.Properties.Resources.about;
            this.btn_about.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_about.Location = new System.Drawing.Point(7, 523);
            this.btn_about.Margin = new System.Windows.Forms.Padding(2);
            this.btn_about.Name = "btn_about";
            this.btn_about.Size = new System.Drawing.Size(221, 55);
            this.btn_about.TabIndex = 4;
            this.btn_about.Text = "     About";
            this.btn_about.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_about.UseVisualStyleBackColor = true;
            this.btn_about.Click += new System.EventHandler(this.btn_about_Click);
            // 
            // btn_file
            // 
            this.Bunifu_Sname.SetDecoration(this.btn_file, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.btn_file, BunifuAnimatorNS.DecorationType.None);
            this.bunifu_Ash.SetDecoration(this.btn_file, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.btn_file, BunifuAnimatorNS.DecorationType.None);
            this.btn_file.FlatAppearance.BorderSize = 0;
            this.btn_file.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_file.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_file.ForeColor = System.Drawing.Color.White;
            this.btn_file.Image = global::Finance.Properties.Resources.file;
            this.btn_file.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_file.Location = new System.Drawing.Point(7, 169);
            this.btn_file.Margin = new System.Windows.Forms.Padding(2);
            this.btn_file.Name = "btn_file";
            this.btn_file.Size = new System.Drawing.Size(221, 55);
            this.btn_file.TabIndex = 3;
            this.btn_file.Text = "     File";
            this.btn_file.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_file.UseVisualStyleBackColor = true;
            this.btn_file.Click += new System.EventHandler(this.btn_file_Click);
            // 
            // btn_entry
            // 
            this.Bunifu_Sname.SetDecoration(this.btn_entry, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.btn_entry, BunifuAnimatorNS.DecorationType.None);
            this.bunifu_Ash.SetDecoration(this.btn_entry, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.btn_entry, BunifuAnimatorNS.DecorationType.None);
            this.btn_entry.FlatAppearance.BorderSize = 0;
            this.btn_entry.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_entry.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_entry.ForeColor = System.Drawing.Color.White;
            this.btn_entry.Image = global::Finance.Properties.Resources.entry;
            this.btn_entry.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_entry.Location = new System.Drawing.Point(12, 228);
            this.btn_entry.Margin = new System.Windows.Forms.Padding(2);
            this.btn_entry.Name = "btn_entry";
            this.btn_entry.Size = new System.Drawing.Size(221, 55);
            this.btn_entry.TabIndex = 2;
            this.btn_entry.Text = "     Entry";
            this.btn_entry.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_entry.UseVisualStyleBackColor = true;
            this.btn_entry.Click += new System.EventHandler(this.btn_entry_Click);
            // 
            // btn_admin
            // 
            this.Bunifu_Sname.SetDecoration(this.btn_admin, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.btn_admin, BunifuAnimatorNS.DecorationType.None);
            this.bunifu_Ash.SetDecoration(this.btn_admin, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.btn_admin, BunifuAnimatorNS.DecorationType.None);
            this.btn_admin.FlatAppearance.BorderSize = 0;
            this.btn_admin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_admin.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_admin.ForeColor = System.Drawing.Color.White;
            this.btn_admin.Image = ((System.Drawing.Image)(resources.GetObject("btn_admin.Image")));
            this.btn_admin.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_admin.Location = new System.Drawing.Point(13, 405);
            this.btn_admin.Margin = new System.Windows.Forms.Padding(2);
            this.btn_admin.Name = "btn_admin";
            this.btn_admin.Size = new System.Drawing.Size(221, 55);
            this.btn_admin.TabIndex = 2;
            this.btn_admin.Text = "     Administrator";
            this.btn_admin.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_admin.UseVisualStyleBackColor = true;
            this.btn_admin.Click += new System.EventHandler(this.btn_admin_Click);
            // 
            // btn_master
            // 
            this.Bunifu_Sname.SetDecoration(this.btn_master, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.btn_master, BunifuAnimatorNS.DecorationType.None);
            this.bunifu_Ash.SetDecoration(this.btn_master, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.btn_master, BunifuAnimatorNS.DecorationType.None);
            this.btn_master.FlatAppearance.BorderSize = 0;
            this.btn_master.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_master.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_master.ForeColor = System.Drawing.Color.White;
            this.btn_master.Image = global::Finance.Properties.Resources.master;
            this.btn_master.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_master.Location = new System.Drawing.Point(11, 346);
            this.btn_master.Margin = new System.Windows.Forms.Padding(2);
            this.btn_master.Name = "btn_master";
            this.btn_master.Size = new System.Drawing.Size(221, 55);
            this.btn_master.TabIndex = 2;
            this.btn_master.Text = "     Master";
            this.btn_master.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_master.UseVisualStyleBackColor = true;
            this.btn_master.Click += new System.EventHandler(this.btn_master_Click);
            // 
            // doubleBitmapControl1
            // 
            this.Bunifu_Slide.SetDecoration(this.doubleBitmapControl1, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.doubleBitmapControl1, BunifuAnimatorNS.DecorationType.None);
            this.bunifu_Ash.SetDecoration(this.doubleBitmapControl1, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Sname.SetDecoration(this.doubleBitmapControl1, BunifuAnimatorNS.DecorationType.None);
            this.doubleBitmapControl1.Location = new System.Drawing.Point(0, 0);
            this.doubleBitmapControl1.Name = "doubleBitmapControl1";
            this.doubleBitmapControl1.Size = new System.Drawing.Size(0, 0);
            this.doubleBitmapControl1.TabIndex = 0;
            this.doubleBitmapControl1.Text = "doubleBitmapControl1";
            this.doubleBitmapControl1.Visible = false;
            // 
            // Bunifu_Logo
            // 
            this.Bunifu_Logo.AnimationType = BunifuAnimatorNS.AnimationType.ScaleAndRotate;
            this.Bunifu_Logo.Cursor = null;
            animation6.AnimateOnlyDifferences = true;
            animation6.BlindCoeff = ((System.Drawing.PointF)(resources.GetObject("animation6.BlindCoeff")));
            animation6.LeafCoeff = 0F;
            animation6.MaxTime = 1F;
            animation6.MinTime = 0F;
            animation6.MosaicCoeff = ((System.Drawing.PointF)(resources.GetObject("animation6.MosaicCoeff")));
            animation6.MosaicShift = ((System.Drawing.PointF)(resources.GetObject("animation6.MosaicShift")));
            animation6.MosaicSize = 0;
            animation6.Padding = new System.Windows.Forms.Padding(30);
            animation6.RotateCoeff = 0.5F;
            animation6.RotateLimit = 0.2F;
            animation6.ScaleCoeff = ((System.Drawing.PointF)(resources.GetObject("animation6.ScaleCoeff")));
            animation6.SlideCoeff = ((System.Drawing.PointF)(resources.GetObject("animation6.SlideCoeff")));
            animation6.TimeCoeff = 0F;
            animation6.TransparencyCoeff = 0F;
            this.Bunifu_Logo.DefaultAnimation = animation6;
            // 
            // Bunifu_Slide
            // 
            this.Bunifu_Slide.AnimationType = BunifuAnimatorNS.AnimationType.ScaleAndHorizSlide;
            this.Bunifu_Slide.Cursor = null;
            animation7.AnimateOnlyDifferences = true;
            animation7.BlindCoeff = ((System.Drawing.PointF)(resources.GetObject("animation7.BlindCoeff")));
            animation7.LeafCoeff = 0F;
            animation7.MaxTime = 1F;
            animation7.MinTime = 0F;
            animation7.MosaicCoeff = ((System.Drawing.PointF)(resources.GetObject("animation7.MosaicCoeff")));
            animation7.MosaicShift = ((System.Drawing.PointF)(resources.GetObject("animation7.MosaicShift")));
            animation7.MosaicSize = 0;
            animation7.Padding = new System.Windows.Forms.Padding(30, 0, 0, 0);
            animation7.RotateCoeff = 0F;
            animation7.RotateLimit = 0F;
            animation7.ScaleCoeff = ((System.Drawing.PointF)(resources.GetObject("animation7.ScaleCoeff")));
            animation7.SlideCoeff = ((System.Drawing.PointF)(resources.GetObject("animation7.SlideCoeff")));
            animation7.TimeCoeff = 0F;
            animation7.TransparencyCoeff = 0F;
            this.Bunifu_Slide.DefaultAnimation = animation7;
            // 
            // Bunifu_Sname
            // 
            this.Bunifu_Sname.AnimationType = BunifuAnimatorNS.AnimationType.ScaleAndRotate;
            this.Bunifu_Sname.Cursor = null;
            animation8.AnimateOnlyDifferences = true;
            animation8.BlindCoeff = ((System.Drawing.PointF)(resources.GetObject("animation8.BlindCoeff")));
            animation8.LeafCoeff = 0F;
            animation8.MaxTime = 1F;
            animation8.MinTime = 0F;
            animation8.MosaicCoeff = ((System.Drawing.PointF)(resources.GetObject("animation8.MosaicCoeff")));
            animation8.MosaicShift = ((System.Drawing.PointF)(resources.GetObject("animation8.MosaicShift")));
            animation8.MosaicSize = 0;
            animation8.Padding = new System.Windows.Forms.Padding(30);
            animation8.RotateCoeff = 0.5F;
            animation8.RotateLimit = 0.2F;
            animation8.ScaleCoeff = ((System.Drawing.PointF)(resources.GetObject("animation8.ScaleCoeff")));
            animation8.SlideCoeff = ((System.Drawing.PointF)(resources.GetObject("animation8.SlideCoeff")));
            animation8.TimeCoeff = 0F;
            animation8.TransparencyCoeff = 0F;
            this.Bunifu_Sname.DefaultAnimation = animation8;
            // 
            // bunifu_Ash
            // 
            this.bunifu_Ash.AnimationType = BunifuAnimatorNS.AnimationType.Leaf;
            this.bunifu_Ash.Cursor = null;
            animation5.AnimateOnlyDifferences = true;
            animation5.BlindCoeff = ((System.Drawing.PointF)(resources.GetObject("animation5.BlindCoeff")));
            animation5.LeafCoeff = 1F;
            animation5.MaxTime = 1F;
            animation5.MinTime = 0F;
            animation5.MosaicCoeff = ((System.Drawing.PointF)(resources.GetObject("animation5.MosaicCoeff")));
            animation5.MosaicShift = ((System.Drawing.PointF)(resources.GetObject("animation5.MosaicShift")));
            animation5.MosaicSize = 0;
            animation5.Padding = new System.Windows.Forms.Padding(0);
            animation5.RotateCoeff = 0F;
            animation5.RotateLimit = 0F;
            animation5.ScaleCoeff = ((System.Drawing.PointF)(resources.GetObject("animation5.ScaleCoeff")));
            animation5.SlideCoeff = ((System.Drawing.PointF)(resources.GetObject("animation5.SlideCoeff")));
            animation5.TimeCoeff = 0F;
            animation5.TransparencyCoeff = 0F;
            this.bunifu_Ash.DefaultAnimation = animation5;
            // 
            // Home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1386, 787);
            this.Controls.Add(this.pnl_admin);
            this.Controls.Add(this.pnl_title);
            this.Controls.Add(this.pnl_all);
            this.Controls.Add(this.pnl_Left);
            this.Bunifu_Sname.SetDecoration(this, BunifuAnimatorNS.DecorationType.None);
            this.bunifu_Ash.SetDecoration(this, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this, BunifuAnimatorNS.DecorationType.None);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Home";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Home";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.pnl_all.ResumeLayout(false);
            this.pnl_administrator.ResumeLayout(false);
            this.pnl_report.ResumeLayout(false);
            this.pnl_file.ResumeLayout(false);
            this.pnl_master.ResumeLayout(false);
            this.pnl_entry.ResumeLayout(false);
            this.pnl_title.ResumeLayout(false);
            this.pnl_title.PerformLayout();
            this.pnl_admin.ResumeLayout(false);
            this.pnl_admin.PerformLayout();
            this.pnl_outTime.ResumeLayout(false);
            this.pnl_inTime.ResumeLayout(false);
            this.pnl_inTime.PerformLayout();
            this.pnl_Lefttop.ResumeLayout(false);
            this.pnl_Lefttop.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_logo)).EndInit();
            this.pnl_Left.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnl_all;
        private System.Windows.Forms.Timer tm_Time;
        private System.Windows.Forms.Panel pnl_title;
        private System.Windows.Forms.Button btn_min;
        private System.Windows.Forms.Label lbl_headAsh;
        private System.Windows.Forms.Button btn_exit;
        private System.Windows.Forms.Panel pnl_admin;
        private System.Windows.Forms.Panel pnl_outTime;
        private System.Windows.Forms.Panel pnl_inTime;
        private System.Windows.Forms.Label lbl_day;
        private System.Windows.Forms.Label lbl_time;
        private System.Windows.Forms.Label lbl_usertype;
        private System.Windows.Forms.Label lbl_role;
        private System.Windows.Forms.Label lbl_user;
        private System.Windows.Forms.Label lbl_welcome;
        private System.Windows.Forms.Panel pnl_Lefttop;
        private System.Windows.Forms.Label lbl_ash;
        private System.Windows.Forms.Button btn_slide;
        private System.Windows.Forms.Label lbl_soft;
        private System.Windows.Forms.PictureBox pb_logo;
        private System.Windows.Forms.Button btn_master;
        private System.Windows.Forms.Button btn_admin;
        private System.Windows.Forms.Button btn_entry;
        private System.Windows.Forms.Panel pnl_slide;
        private System.Windows.Forms.Button btn_file;
        private System.Windows.Forms.Button btn_about;
        private System.Windows.Forms.Button btn_mail;
        private System.Windows.Forms.Panel pnl_Left;
        private System.Windows.Forms.Button btn_report;
        private BunifuAnimatorNS.BunifuTransition bunifu_Ash;
        private BunifuAnimatorNS.BunifuTransition Bunifu_Logo;
        private BunifuAnimatorNS.BunifuTransition Bunifu_Slide;
        private BunifuAnimatorNS.BunifuTransition Bunifu_Sname;
        private BunifuAnimatorNS.DoubleBitmapControl doubleBitmapControl1;
        private System.Windows.Forms.Panel pnl_entry;
        private System.Windows.Forms.Button btn_loan;
        private System.Windows.Forms.Button btn_collection;
        private System.Windows.Forms.Panel pnl_file;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Panel pnl_master;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Panel pnl_administrator;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button button38;
        private System.Windows.Forms.Button button39;
        private System.Windows.Forms.Button button41;
        private System.Windows.Forms.Button button42;
        private System.Windows.Forms.Button button44;
        private System.Windows.Forms.Button button45;
        private System.Windows.Forms.Panel pnl_report;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Panel pnl_gap4;
        private System.Windows.Forms.Button btn_passbookChecking;
        private System.Windows.Forms.Panel pnl_gap3;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Panel pnl_gap2;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Panel pnl_gap1;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Panel pnl_main;
    }
}